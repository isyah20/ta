/*-=======================================
		#	DATA TABLE ADMIN	  #
========================================-*/
document.addEventListener("DOMContentLoaded", function () {
	let table = new DataTable("#table_admin");
});
