// Sliders---------------------------------------------------------------
let slideIndex = 0;
showSlides();

function showSlides() {
	let i;
	let slides = document.getElementsByClassName("mySlides");
	let dots = document.getElementsByClassName("partner-dot");
	for (i = 0; i < slides.length; i++) {
		slides[i].style.display = "none";
	}
	slideIndex++;
	if (slideIndex > slides.length) {
		slideIndex = 1;
	}
	for (i = 0; i < dots.length; i++) {
		dots[i].className = dots[i].className.replace(" partner-active", "");
	}
	slides[slideIndex - 1].style.display = "block";
	dots[slideIndex - 1].className += " partner-active";
	setTimeout(showSlides, 5000); // Change image every 2 seconds
}
/* --------------------------------------------
            #TESTIMONI SLIDERS#
-----------------------------------------------*/
var slideTesti = 0;
showTesti();
var slidestesti;
//Button sliders
function plusSlides(position) {
	slideTesti += position;
	if (slideTesti > slidestesti.length) {
		slideTesti = 1;
	} else if (slideTesti < 1) {
		slideTesti = slidestesti.length;
	}
	for (d = 0; d < slidestesti.length; d++) {
		slidestesti[d].style.display = "none";
	}
	slidestesti[slideTesti - 1].style.display = "block";
}
//automatic sliders
function showTesti() {
	var d;
	slidestesti = document.getElementsByClassName("testiSlides");
	for (d = 0; d < slidestesti.length; d++) {
		slidestesti[d].style.display = "none";
	}
	slideTesti++;
	if (slideTesti > slidestesti.length) {
		slideTesti = 1;
	}
	slidestesti[slideTesti - 1].style.display = "block";
	setTimeout(showTesti, 8000);
}

/*---------------------------------------------
				#	FITUR SLIDE	#
-----------------------------------------------*/
let slidefitur = 1;
showSlidesfitur(slidefitur);

function plusSlidesfitur(n) {
	showSlidesfitur((slidefitur += n));
}
var sliderTime;
function currentSlidefitur(n) {
	if (sliderTime) window.clearTimeout(sliderTime);
	showSlidesfitur((slidefitur = n));
}

function showSlidesfitur(n) {
	let i;
	let slidesfiturin = document.getElementsByClassName("fiturslide");
	let dotsin = document.getElementsByClassName("dot-fitur");
	if (n > slidesfiturin.length) {
		slidefitur = 1;
	}
	if (n < 1) {
		slidefitur = slidesfiturin.length;
	}
	for (i = 0; i < slidesfiturin.length; i++) {
		slidesfiturin[i].style.display = "none";
	}
	if (!n) {
		slidefitur++;
	}
	if (slidefitur > slidesfiturin.length) {
		slidefitur = 1;
	}
	for (i = 0; i < dotsin.length; i++) {
		dotsin[i].className = dotsin[i].className.replace(" active", "");
	}
	slidesfiturin[slidefitur - 1].style.display = "block";
	dotsin[slidefitur - 1].className += " active";
	sliderTime = setTimeout(showSlidesfitur, 10000);
}
