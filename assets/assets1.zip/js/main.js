(function ($) {
    // Initiate the wowjs
    new WOW().init();
})(jQuery);